package com.danwob.aitimetable

data class TaskItem(
    val id: Long,
    val title: String,
    val time: String,
    val done: Boolean = false
)
