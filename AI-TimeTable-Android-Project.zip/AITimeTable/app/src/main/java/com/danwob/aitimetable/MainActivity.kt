package com.danwob.aitimetable

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Bg = Color(0xFF0B0D12)
private val Panel = Color(0xFF171B26)
private val Accent = Color(0xFF9B8CFF)
private val Muted = Color(0xFF9AA3B2)

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { TimeTableScreen(this) }
    }
}

@Composable
private fun TimeTableScreen(context: Context) {
    var tasks by remember { mutableStateOf(loadTasks(context)) }
    var prompt by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("Suggest first") }
    var editing by remember { mutableStateOf<TaskItem?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf("Describe your tasks and let the planner arrange a draft.") }

    fun save(updated: List<TaskItem>) {
        tasks = updated.sortedBy { parseTime(it.time) }
        saveTasks(context, tasks)
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("AI TimeTable", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Plan your day. Stay on track.", color = Muted, fontSize = 13.sp)
                    }
                    Box(Modifier.size(42.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.NotificationsActive, null, tint = Accent)
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text("AI PLANNER", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = prompt, onValueChange = { prompt = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp),
                    placeholder = { Text("Example: Tomorrow school 8–2, science study 1 hour, English homework...") },
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Accent, unfocusedBorderColor = Color(0xFF343A49),
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        cursorColor = Accent
                    )
                )
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Planning mode", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    FilterChip(selected = mode == "Automatic", onClick = { mode = "Automatic" }, label = { Text("Automatic") })
                    Spacer(Modifier.width(6.dp))
                    FilterChip(selected = mode == "Suggest first", onClick = { mode = "Suggest first" }, label = { Text("Suggest first") })
                }
                Button(
                    onClick = {
                        if (prompt.isNotBlank()) {
                            val draft = makeDraft(prompt)
                            if (mode == "Automatic") {
                                save(tasks + draft)
                                draft.forEach { scheduleReminder(context, it) }
                                info = "Added ${draft.size} suggested task(s). You can edit them below."
                            } else {
                                editing = TaskItem(-1L, draft.joinToString(" • ") { "${it.time} ${it.title}" }, "Review draft")
                                info = "Review the draft below. Add or edit individual tasks using + Add task."
                            }
                            prompt = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFF11121A))
                    Spacer(Modifier.width(8.dp))
                    Text("Create my timetable", color = Color(0xFF11121A), fontWeight = FontWeight.Bold)
                }
                Text(info, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 7.dp))
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("TODAY'S SCHEDULE", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
                    Text("${tasks.count { it.done }}/${tasks.size} done", color = Accent, fontSize = 12.sp)
                }
                Spacer(Modifier.height(10.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.weight(1f)) {
                    items(tasks, key = { it.id }) { task ->
                        TaskCard(task, onDone = {
                            save(tasks.map { if (it.id == task.id) it.copy(done = !it.done) else it })
                        }, onEdit = { editing = task }, onDelete = {
                            save(tasks.filterNot { it.id == task.id })
                        })
                    }
                    item {
                        OutlinedButton(
                            onClick = { showAdd = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Accent)
                        ) {
                            Icon(Icons.Default.Add, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Add task manually")
                        }
                    }
                    item {
                        Text("AI connection: setup required in the next build stage.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 12.dp))
                    }
                }
            }
        }
    }

    if (showAdd) TaskEditor(null, onDismiss = { showAdd = false }, onSave = { title, time ->
        val task = TaskItem(System.currentTimeMillis(), title, time)
        save(tasks + task); scheduleReminder(context, task); showAdd = false
    })
    editing?.let { task ->
        if (task.id == -1L) {
            AlertDialog(onDismissRequest = { editing = null }, title = { Text("Suggested timetable") },
                text = { Text(task.title) },
                confirmButton = { TextButton(onClick = {
                    val generated = task.title.split(" • ").mapNotNull { line ->
                        val match = Regex("^(\\d{1,2}:\\d{2})\\s+(.+)$").find(line)
                        match?.let { TaskItem(System.currentTimeMillis() + (0..9999).random(), it.groupValues[2], it.groupValues[1]) }
                    }
                    save(tasks + generated); generated.forEach { scheduleReminder(context, it) }; editing = null
                }) { Text("Approve draft") } },
                dismissButton = { TextButton(onClick = { editing = null }) { Text("Close") } })
        } else TaskEditor(task, onDismiss = { editing = null }, onSave = { title, time ->
            val updated = tasks.map { if (it.id == task.id) it.copy(title = title, time = time) else it }
            save(updated); updated.firstOrNull { it.id == task.id }?.let { scheduleReminder(context, it) }; editing = null
        })
    }
}

@Composable
private fun TaskCard(task: TaskItem, onDone: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).background(Color(0xFF28243F), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Schedule, null, tint = Accent)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(task.title, color = if (task.done) Muted else Color.White, fontWeight = FontWeight.SemiBold)
            Text(task.time, color = Muted, fontSize = 12.sp)
        }
        IconButton(onClick = onDone) { Icon(Icons.Default.Check, null, tint = if (task.done) Color(0xFF63D6A2) else Muted) }
        IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, null, tint = Accent) }
        IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, null, tint = Color(0xFFE58B8B)) }
    }
}

@Composable
private fun TaskEditor(task: TaskItem?, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var title by remember(task) { mutableStateOf(task?.title ?: "") }
    var time by remember(task) { mutableStateOf(task?.time ?: "18:00") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (task == null) "Add task" else "Edit task") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Task name") }, singleLine = true)
                OutlinedTextField(time, { time = it }, label = { Text("Time (24-hour, HH:mm)") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { if (title.isNotBlank() && Regex("^([01]?\\d|2[0-3]):[0-5]\\d$").matches(time)) onSave(title.trim(), time) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun makeDraft(input: String): List<TaskItem> {
    // Starter placeholder: splits written tasks into a draft. A real AI service is connected in a later stage.
    val cleaned = input.replace(Regex("(?i)tomorrow|today|please|i need to|i have to|also"), "")
    val parts = cleaned.split(Regex("[,;\\n]| and ")).map { it.trim().trim('.', ' ') }.filter { it.length > 3 }
    val formatter = DateTimeFormatter.ofPattern("HH:mm", Locale.US)
    return parts.take(8).mapIndexed { index, part ->
        val hour = 9 + index
        TaskItem(System.currentTimeMillis() + index, part.replaceFirstChar { it.uppercase() }, LocalTime.of(hour.coerceAtMost(20), 0).format(formatter))
    }
}

private fun parseTime(value: String): Int = try {
    val p = value.split(":"); p[0].toInt() * 60 + p[1].toInt()
} catch (_: Exception) { 9999 }

private fun saveTasks(context: Context, tasks: List<TaskItem>) {
    val array = JSONArray()
    tasks.forEach { array.put(JSONObject().put("id", it.id).put("title", it.title).put("time", it.time).put("done", it.done)) }
    context.getSharedPreferences("planner", Context.MODE_PRIVATE).edit().putString("tasks", array.toString()).apply()
}
private fun loadTasks(context: Context): List<TaskItem> = try {
    val array = JSONArray(context.getSharedPreferences("planner", Context.MODE_PRIVATE).getString("tasks", "[]"))
    (0 until array.length()).map { i ->
        val o = array.getJSONObject(i); TaskItem(o.getLong("id"), o.getString("title"), o.getString("time"), o.optBoolean("done"))
    }
} catch (_: Exception) { emptyList() }

private fun scheduleReminder(context: Context, task: TaskItem) {
    val parts = task.time.split(":")
    if (parts.size != 2) return
    val cal = java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.HOUR_OF_DAY, parts[0].toIntOrNull() ?: return)
        set(java.util.Calendar.MINUTE, parts[1].toIntOrNull() ?: return)
        set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        if (timeInMillis <= System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR, 1)
    }
    val intent = Intent(context, ReminderReceiver::class.java).putExtra("title", task.title)
    val pending = PendingIntent.getBroadcast(context, task.id.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
}
