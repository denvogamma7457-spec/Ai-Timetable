# AI TimeTable — Android starter project

This is a native Kotlin + Jetpack Compose Android starter app.

## Included in this first build
- Dark-mode timetable screen
- Written task input and two planning modes
- Task list with add, edit, delete and complete actions
- Local task storage
- Basic Android reminder notifications
- GitHub Actions workflow to compile a debug APK in the cloud

## Important AI status
The planner currently creates a simple draft from text using a basic local splitter. It is **not yet connected to an AI model**. The next development stage is to connect a secure AI backend. Do not put a private AI API key directly inside the APK.

## Build with GitHub Actions
1. Create a new GitHub repository and upload the contents of this ZIP.
2. Open the repository's **Actions** tab and enable workflows if prompted.
3. Choose **Build Android APK** and tap **Run workflow**.
4. Open the completed run and download the `AI-TimeTable-debug-apk` artifact.
5. Extract the artifact ZIP to find `app-debug.apk`.

Package: `com.danwob.aitimetable`
Minimum Android: 8.0 (API 26)
